package olimpicos;
import java.util.ArrayList;
import java.util.Scanner;

public class Olimpicos {
    
    public static void Menu(ArrayList <Delegacion> listaDelegaciones){
        System.out.println();
        System.out.println("1. Crear Delegacion");
        System.out.println("2. Consultar Delegacion");
        System.out.println("3. Modificar Medalleria");
        System.out.println("4. Identificar Delegacion con mas medallas");
        System.out.println("5. Salir");
        Scanner entradaMenu= new Scanner(System.in);
        int opcionMenu= entradaMenu.nextInt();
        if(opcionMenu==1){
           CrearDelegacion(listaDelegaciones);
        }
        if(opcionMenu==2){
            ConsultarDelegacion(listaDelegaciones);
            
        }
        if(opcionMenu==3){
            CambiarMedalleriaDelegacion(listaDelegaciones);
        }
        if(opcionMenu==4){
            ConsultarDelegacionConMasMedallas(listaDelegaciones);
            
        }
          
        if(opcionMenu==5){
            System.exit(0); 
        }
        else{
            
            Menu(listaDelegaciones);
            }
    }
    
    public static void CrearDelegacion(ArrayList <Delegacion> listaDelegaciones){
        Delegacion delegacion = new Delegacion();
        System.out.println("¿De que  Pais es la delegacion?");
        Scanner entradaPais= new Scanner(System.in);
        String nombrePais= entradaPais.nextLine();
        delegacion.setPais(nombrePais);
        ArrayList <GrupoDeportivo> listaGrupoDeportivo= new ArrayList <GrupoDeportivo> ();
       for(int i=0; i<5;i++){
           GrupoDeportivo grupoDeportivo =new GrupoDeportivo();
           System.out.println("Ingrese el nombre del deporte");
           Scanner entradaDeporte= new Scanner(System.in);
           String nombreDeporte= entradaDeporte.nextLine();
           grupoDeportivo.setNombreDeporte(nombreDeporte);
           listaGrupoDeportivo.add(grupoDeportivo);
           ArrayList <Integrante> listaIntegrantes= new ArrayList <Integrante> ();
           for(int j=0;j<10;j++){
               System.out.println();
               Integrante integrante= new Integrante();
               System.out.println("Ingrese el nombre del deportista");
               Scanner entradaIntegrante01= new Scanner(System.in);
               String nombreIntegrante= entradaIntegrante01.nextLine();
               integrante.setNombre(nombreIntegrante);
               System.out.println("Ingrese el apellido del deportista");
               Scanner entradaIntegrante02= new Scanner(System.in);
               String apellidoIntegrante= entradaIntegrante02.nextLine();
               integrante.setApellido(apellidoIntegrante);
               listaIntegrantes.add(integrante);
               if(j>0){
                   System.out.println();
                   System.out.println("desea ingresar otro deportista");
                   System.out.println("1. SI");
                   System.out.println("2. NO");
                   Scanner entradaSubmenu= new Scanner(System.in);
                   int opcionMenu=  entradaSubmenu.nextInt();
                   System.out.println();
                   if (opcionMenu==2){
                       break;
                   }
                   
               }
               
           }
           grupoDeportivo.setIntegrantes(listaIntegrantes);
          
                 
           
           
       }
       delegacion.setDelegaciones(listaGrupoDeportivo);       
        listaDelegaciones.add(delegacion);
        Menu(listaDelegaciones);
    }
    
    public static void ConsultarDelegacion(ArrayList <Delegacion> listaDelegaciones){
        System.out.println("Ingrese el deporte a consultar");
        Scanner entradaDeporte= new Scanner(System.in);
        String nombreDeporte= entradaDeporte.nextLine();
        for(Delegacion delegacion: listaDelegaciones){
            for(GrupoDeportivo grupoDeportivo: delegacion.getDelegaciones()){
                if(grupoDeportivo.getNombreDeporte().equals(nombreDeporte)){
                    System.out.println("Pais: "+delegacion.getPais()+" Deporte: "+grupoDeportivo.getNombreDeporte());
                    for(Integrante integrante: grupoDeportivo.getIntegrantes()){
                        System.out.println(integrante.getNombre()+" "+integrante.getApellido());
                    }
                }
            }
            
        }
        Menu(listaDelegaciones);        
    }
    public static void CambiarMedalleriaDelegacion(ArrayList <Delegacion> listaDelegaciones){
        if(!listaDelegaciones.isEmpty()){
        System.out.println("Ingrese el pais de la delegacion a modificar medalleria");
        Scanner entradaPais= new Scanner(System.in);
        String nombrePais= entradaPais.nextLine();
        int i=0;
        for(Delegacion delegacion: listaDelegaciones){
            if(delegacion.getPais().equals(nombrePais)){
                System.out.println("1. Modificar oros");
                System.out.println("2. Modificar Platas");
                System.out.println("3. Modificar Bronces");
                Scanner opcion= new Scanner(System.in);
                int opcionMenu= opcion.nextInt();
                if(opcionMenu==1){
                     System.out.println("cantidad de oros:");
                     Scanner cantidadOros= new Scanner(System.in);
                     int oros=cantidadOros.nextInt();
                     delegacion.setMedallasOro(oros);
                     
                }
                if(opcionMenu==2){
                     System.out.println("cantidad de platas:");
                     Scanner cantidadPlatas= new Scanner(System.in);
                     int platas=cantidadPlatas.nextInt();
                     delegacion.setMedallasPlata(platas);
                     
                     
                }
                if(opcionMenu==3){
                     System.out.println("cantidad de Bronces:");
                     Scanner cantidadBronces= new Scanner(System.in);
                     int bronces=cantidadBronces.nextInt();
                     delegacion.setMedallasBronce(bronces);
                     
                }
                delegacion.setTotalMedallas(delegacion.getMedallasOro()+delegacion.getMedallasPlata()+delegacion.getMedallasBronce());
                listaDelegaciones.set(i, delegacion);
            }
            i++;
        }
        Menu(listaDelegaciones);
    }
        else{System.out.println("NO HA INGRESADO ALGUNA DELEGACION");}
    }
    
    public static void ConsultarDelegacionConMasMedallas(ArrayList <Delegacion> listaDelegaciones){
        if(!listaDelegaciones.isEmpty()){            
            int mayor= listaDelegaciones.get(0).getTotalMedallas();
        for(Delegacion delegacion: listaDelegaciones){
            if(delegacion.getTotalMedallas()>mayor){
                mayor=delegacion.getTotalMedallas();
                
            }
            
        }
        for(Delegacion delegacion: listaDelegaciones){
            if(delegacion.getTotalMedallas()==mayor){
                System.out.println("La delegacion con mayor medallas es la de: "+delegacion.getPais()+" Con un total de "+ delegacion.getTotalMedallas()+" medallas");
            }
        }
        }
        else{
            System.out.println("NO HA INGRESADO ALGUNA DELEGACION");
        }
    }


    public static void main(String[] args) {
         System.out.println("Bienvenido al programa de gestion de mini-juegos olimpicos ");
         ArrayList <Delegacion> listaDelegaciones= new ArrayList <Delegacion> ();
         Menu(listaDelegaciones);
    }
    
}
