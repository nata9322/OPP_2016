
package olimpicos;
import java.util.List;

public class GrupoDeportivo {
    
    private String nombreDeporte;
    private List<Integrante> integrantes;

    public void setNombreDeporte(String nombreDeprote) {
        this.nombreDeporte = nombreDeprote;
    }

    public void setIntegrantes(List<Integrante> integrantes) {
        this.integrantes = integrantes;
    }

    public String getNombreDeporte() {
        return nombreDeporte;
    }

    public List<Integrante> getIntegrantes() {
        return integrantes;
    }
    
    
    
}
