
package olimpicos;
import java.util.List;

public class Delegacion {
    private int numeroDeDeportistas;
    private int medallasOro;
    private int medallasPlata;
    private int medallasBronce;
    private int totalMedallas;

    public void setTotalMedallas(int totalMedallas) {
        this.totalMedallas = totalMedallas;
    }

    

    public int getTotalMedallas() {
        return totalMedallas;
    }
    private String pais;
    private List<GrupoDeportivo> delegaciones;

    public void setDelegaciones(List<GrupoDeportivo> delegaciones) {
        this.delegaciones = delegaciones;
    }

    public List<GrupoDeportivo> getDelegaciones() {
        return delegaciones;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public void setNumeroDeDeportistas(int numeroDeDeportistas) {
        this.numeroDeDeportistas = numeroDeDeportistas;
    }

    public void setMedallasOro(int medallasOro) {
        this.medallasOro = medallasOro;
    }

    public void setMedallasPlata(int medallasPlata) {
        this.medallasPlata = medallasPlata;
    }

    public void setMedallasBronce(int medallasBronce) {
        this.medallasBronce = medallasBronce;
    }
    
    public int getNumeroDeDeportistas() {
        return numeroDeDeportistas;
    }

    public int getMedallasOro() {
        return medallasOro;
    }

    public int getMedallasPlata() {
        return medallasPlata;
    }

    public int getMedallasBronce() {
        return medallasBronce;
    }

    public String getPais() {
        return pais;
    }
    
    
    
    
}
