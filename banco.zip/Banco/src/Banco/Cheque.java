
package Banco;

public class Cheque extends Cuenta{
    double comisionUso;

    public double getComisionUso() {
        return comisionUso;
    }

    public void setComisionUso(double comisionUso) {
        this.comisionUso = comisionUso;
    }

    public double getComisionEmision() {
        return comisionEmision;
    }

    public void setComisionEmision(double comisionEmision) {
        this.comisionEmision = comisionEmision;
    }
    double comisionEmision;
    
    public void Retiro(double retiro){
        if(this.getSaldo()<retiro){
            this.setSaldo(retiro*this.getComisionEmision());
            
        }
    }
    
    
}
