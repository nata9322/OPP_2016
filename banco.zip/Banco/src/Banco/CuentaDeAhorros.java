
package Banco;

public class CuentaDeAhorros extends Cuenta{
    int dia;
    int mes;
    int anno;
    double porcentajeDeInteresMensual;
    
    public void depositointeres(int dia){
        if (dia==1){
            this.setSaldo(this.getSaldo()*this.porcentajeDeInteresMensual);
            
            
        }
    }
    
    
    
    public void retiro(double retiro, int dia, int mes, int anno){
    if(dia==this.dia&&mes==this.mes&&anno==this.anno){
        this.retiro(retiro);
    }
    }
    
}
