
package Banco;


public class Cuenta {
    
    int numeroDeCuenta;
    String nombreDelCliente;
    double saldo;

    public int getNumeroDeCuenta() {
        return numeroDeCuenta;
    }

    public void setNumeroDeCuenta(int numeroDeCuenta) {
        this.numeroDeCuenta = numeroDeCuenta;
    }

    public String getNombreDelCliente() {
        return nombreDelCliente;
    }

    public void setNombreDelCliente(String nombreDelCliente) {
        this.nombreDelCliente = nombreDelCliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public void consultarDatos(){
        System.out.println(this.getNumeroDeCuenta()+" "+this.getNombreDelCliente()+" "+this.getSaldo());
    }
    
    public void incrementarSaldo(double consignación){
        this.setSaldo(this.getSaldo()+consignación);
    }
    
    public void retiro(double retiro){
        if (this.getSaldo()>=retiro){
            this.setSaldo(this.getSaldo()-retiro);
            
        }
    }
        

   
    public static void main(String[] args) {
        
     
    }
    
}
