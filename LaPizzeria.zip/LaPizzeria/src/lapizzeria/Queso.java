
package lapizzeria;


public class Queso implements Pizza{
    @Override
    public void prepararAmasar() {
        System.out.println("Se esta amasando la masa de corteza regular");
    }

    @Override
    public void adicionarSalsas() {
        System.out.println("Se esta adicionando la salsa de tomate");
    }

    @Override
    public void adicionarIngredientes() {
        System.out.println("Se esta añadiendo estos ingredientes: ");
        System.out.println("Queso Mozzarella fresco, Parmesano.");
    }

    @Override
    public void ornear() {
        System.out.println("Se esta orneando, tiempo 15 minutos");
        
    }

    @Override
    public void Cortar() {
        System.out.println("Se esta cortando en forma triangular");
        
    }

    @Override
    public void empacar() {
        System.out.println("Se esta empacando en caja ");
        System.out.println("Lista la pizza");
    }
}
