
package lapizzeria ;


public class Vegetariana implements Pizza {

    @Override
    public void prepararAmasar() {
        System.out.println("Se esta amasando la masa regular");
    }

    @Override
    public void adicionarSalsas() {
        System.out.println("Se esta adicionando la salsa de tomate");
        
    }

    @Override
    public void adicionarIngredientes() {
        System.out.println("Se esta añadiendo estos ingredientes: ");
        System.out.println("mozzarella, parmesano rallado, cebolla picada, hongosen rebanadas, pimientaroja en rodajas, aceitunas negras rebanadas");
        
    }

    @Override
    public void ornear() {
        System.out.println("Se esta orneando, tiempo 15 minutos");
        
    }

    @Override
    public void Cortar() {
        System.out.println("Se esta cortando en forma triangular");
        
    }

    @Override
    public void empacar() {
        System.out.println("Se esta empacando en caja ");
        System.out.println("Lista la pizza");
    }
    
    
    
}
