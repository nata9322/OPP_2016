
package lapizzeria;


public interface Pizza {    
    public void prepararAmasar();    
    public void adicionarSalsas();
    public void adicionarIngredientes();
    public void ornear();
    public void Cortar();
    public void empacar();
}
