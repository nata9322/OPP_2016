
package lapizzeria;
import java.util.Scanner;

public class LaPizzeria {
    
    public static void menu(){
      System.out.println("BIENVENDIO A LaPizzeria");
      System.out.println("");
      System.out.println("¿Que tipo de Pizza desea ordenar?");
      System.out.println("");
      System.out.println("1. Vegetariana");
      System.out.println("2. Peperoni");
      System.out.println("3. Queso");      
      Scanner entradaMenu= new Scanner(System.in);
      int i= entradaMenu.nextInt();
      switch(i){
          case 1:
              Vegetariana vegetariana= new Vegetariana();
              vegetariana.prepararAmasar();
              vegetariana.adicionarSalsas();
              vegetariana.adicionarIngredientes();
              vegetariana.ornear();
              vegetariana.Cortar();
              vegetariana.empacar();
              break;
          case 2:
              Peperoni peperoni= new Peperoni();
              peperoni.prepararAmasar();
              peperoni.adicionarSalsas();
              peperoni.adicionarIngredientes();
              peperoni.ornear();
              peperoni.Cortar();
              break;
          case 3:
              Queso queso= new Queso();
              queso.prepararAmasar();
              queso.adicionarSalsas();
              queso.adicionarIngredientes();
              queso.ornear();
              queso.Cortar();
              break;
          default:
              System.out.println("");
              System.out.println("***Opcion incorrecta***");
              System.out.println("");
              menu();
              break;             
              
      }}

    
    public static void main(String[] args) {
        menu();    
    }
    
}
