/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author panamericana
 */
public class DEmpresa implements IEmpresa{
     private String nomemp,diremp,coremp,ubiemp,pagwemp,descrip;
    private int codemp,nit,telemp;
    
     public DEmpresa(String nomemp, String diremp, String coremp, String ubiemp, String pagwemp, String descrip, int codemp, int nit, int telemp) {
        this.nomemp = nomemp;
        this.diremp = diremp;
        this.coremp = coremp;
        this.ubiemp = ubiemp;
        this.pagwemp = pagwemp;
        this.descrip = descrip;
        this.codemp = codemp;
        this.nit = nit;
        this.telemp = telemp;
    }
     
    @Override
      public String getNomemp() {
        return nomemp;
    }

    @Override
    public void setNomemp(String nomemp) {
        this.nomemp = nomemp;
    }

    @Override
    public String getDiremp() {
        return diremp;
    }

    @Override
    public void setDiremp(String diremp) {
        this.diremp = diremp;
    }

    @Override
    public String getCoremp() {
        return coremp;
    }

    @Override
    public void setCoremp(String coremp) {
        this.coremp = coremp;
    }

    @Override
    public String getUbiemp() {
        return ubiemp;
    }

    @Override
    public void setUbiemp(String ubiemp) {
        this.ubiemp = ubiemp;
    }

    @Override
    public String getPagwemp() {
        return pagwemp;
    }

    @Override
    public void setPagwemp(String pagwemp) {
        this.pagwemp = pagwemp;
    }

    @Override
    public String getDescrip() {
        return descrip;
    }

    @Override
    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    @Override
    public long getCodemp() {
        return codemp;
    }

    @Override
    public void setCodemp(int codemp) {
        this.codemp = codemp;
    }

    @Override
    public long getNit() {
        return nit;
    }

    @Override
    public void setNit(int nit) {
        this.nit = nit;
    }

    @Override
    public long getTelemp() {
        return telemp;
    }

    @Override
    public void setTelemp(int telemp) {
        this.telemp = telemp;
    }
    @Override
 public String toString() {
        return "DConvocatorias{" + "nomemp=" + nomemp + ", diremp=" + diremp + ", coremp=" + coremp + ", ubiemp=" + ubiemp + ", pagwemp=" + pagwemp + ", descrip=" + descrip + ", nit=" + nit + ", telemp=" + telemp + '}';
    }
  
}
