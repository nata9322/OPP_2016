/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author panamericana
 */
public class DAspirante extends Usuario implements Serializable{
    
    private String nomasp,dirasp,fechanaci,lugarnaci,estadocasp,sexoasp,corrasp,ubiasp,idiomaasp,fechapubasp,expasp,dexpasp,reffasp,refpasp,profasp;
    private long ccasp,telasp,edadasp;

    public DAspirante(String nomasp, String dirasp, String fechanaci, String lugarnaci, String estadocasp, String sexoasp, String corrasp, String ubiasp, String idiomaasp,String profasp, String fechapubasp, String expasp, String dexpasp, String reffasp, String refpasp, long ccasp, long telasp, long edadasp, String usuario, String tipo, String nombreusuario, String contraseña) {
        super(usuario, tipo, nombreusuario, contraseña);
       
        this.nomasp = nomasp;
        this.dirasp = dirasp;
        this.fechanaci = fechanaci;
        this.lugarnaci = lugarnaci;
        this.estadocasp = estadocasp;
        this.sexoasp = sexoasp;
        this.corrasp = corrasp;
        this.ubiasp = ubiasp;
        this.idiomaasp = idiomaasp;
         this.profasp=profasp;
        this.fechapubasp = fechapubasp;
        this.expasp = expasp;
        this.dexpasp = dexpasp;
        this.reffasp = reffasp;
        this.refpasp = refpasp;
        this.ccasp = ccasp;
        this.telasp = telasp;
        this.edadasp = edadasp;
    }
    public DAspirante(String usuario,String tipo,String nombreusuario,String contraseña){
        super(usuario, tipo, nombreusuario, contraseña);
           }
    
    public String getNomasp() {
        return nomasp;
    }

    public String getProfasp() {
        return profasp;
    }

    public void setProfasp(String profasp) {
        this.profasp = profasp;
    }

    public void setNomasp(String nomasp) {
        this.nomasp = nomasp;
    }

    public String getDirasp() {
        return dirasp;
    }

    public void setDirasp(String dirasp) {
        this.dirasp = dirasp;
    }

    public String getFechanaci() {
        return fechanaci;
    }

    public void setFechanaci(String fechanaci) {
        this.fechanaci = fechanaci;
    }

    public String getLugarnaci() {
        return lugarnaci;
    }

    public void setLugarnaci(String lugarnaci) {
        this.lugarnaci = lugarnaci;
    }

    public String getEstadocasp() {
        return estadocasp;
    }

    public void setEstadocasp(String estadocasp) {
        this.estadocasp = estadocasp;
    }

    public String getSexoasp() {
        return sexoasp;
    }

    public void setSexoasp(String sexoasp) {
        this.sexoasp = sexoasp;
    }

    public String getCorrasp() {
        return corrasp;
    }

    public void setCorrasp(String corrasp) {
        this.corrasp = corrasp;
    }

    public String getUbiasp() {
        return ubiasp;
    }

    public void setUbiasp(String ubiasp) {
        this.ubiasp = ubiasp;
    }

    public String getIdiomaasp() {
        return idiomaasp;
    }

    public void setIdiomaasp(String idiomaasp) {
        this.idiomaasp = idiomaasp;
    }

    public String getFechapubasp() {
        return fechapubasp;
    }

    public void setFechapubasp(String fechapubasp) {
        this.fechapubasp = fechapubasp;
    }

    public String getExpasp() {
        return expasp;
    }

    public void setExpasp(String expasp) {
        this.expasp = expasp;
    }

    public String getDexpasp() {
        return dexpasp;
    }

    public void setDexpasp(String dexpasp) {
        this.dexpasp = dexpasp;
    }

    public String getReffasp() {
        return reffasp;
    }

    public void setReffasp(String reffasp) {
        this.reffasp = reffasp;
    }

    public String getRefpasp() {
        return refpasp;
    }

    public void setRefpasp(String refpasp) {
        this.refpasp = refpasp;
    }

    public long getCcasp() {
        return ccasp;
    }

    public void setCcasp(long ccasp) {
        this.ccasp = ccasp;
    }

    public long getTelasp() {
        return telasp;
    }

    public void setTelasp(long telasp) {
        this.telasp = telasp;
    }

    public long getEdadasp() {
        return edadasp;
    }

    public void setEdadasp(long edadasp) {
        this.edadasp = edadasp;
    }

   
}
