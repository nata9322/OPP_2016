/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author Castillo
 */
public interface IConvocatorias extends Serializable {

    String getCiudadconv();

    String getDireccionemp();

    String getExpeconv();

    String getFechaconv();

    String getIdioconv();

    String getNomconv();

    String getNomreemp();

    String getProfeconv();

    long getSalario();

    long getTelemp();

    long getVacantes();

    void setCiudadconv(String ciudadconv);

    void setDireccionemp(String direccionemp);

    void setExpeconv(String expeconv);

    void setFechaconv(String fechaconv);

    void setIdioconv(String idioconv);

    void setNomconv(String nomconv);

    void setNomreemp(String nomreemp);

    void setProfeconv(String profeconv);

    void setSalario(long salario);

    void setTelemp(long telemp);

    void setVacantes(long vacantes);
    
}
