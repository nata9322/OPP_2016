/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author Castillo
 */
public interface IEmpresa extends Serializable {

    long getCodemp();

    String getCoremp();

    String getDescrip();

    String getDiremp();

    long getNit();

    String getNomemp();

    String getPagwemp();

    long getTelemp();

    String getUbiemp();

    void setCodemp(int codemp);

    void setCoremp(String coremp);

    void setDescrip(String descrip);

    void setDiremp(String diremp);

    void setNit(int nit);

    void setNomemp(String nomemp);

    void setPagwemp(String pagwemp);

    void setTelemp(int telemp);

    void setUbiemp(String ubiemp);

    String toString();
    
}
