/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author panamericana
 */
public class DAdministrador  extends Usuario implements Serializable {
    
    private String nombadm,diradm,fechanacadm,lugarnacadm,estadocadmm,sexoadm,corradm,ubiadm;
    private long ccadm,teladm,edadadm,codadm;

    public DAdministrador(String nombadm, String diradm, String fechanacadm, String lugarnacadm, String estadocadmm, String sexoadm, String corradm, String ubiadm, long ccadm, long teladm, long edadadm, long codadm, String usuario, String tipo, String nombreusuario, String contraseña) {
        super(usuario, tipo, nombreusuario, contraseña);
        this.nombadm = nombadm;
        this.diradm = diradm;
        this.fechanacadm = fechanacadm;
        this.lugarnacadm = lugarnacadm;
        this.estadocadmm = estadocadmm;
        this.sexoadm = sexoadm;
        this.corradm = corradm;
        this.ubiadm = ubiadm;
        this.ccadm = ccadm;
        this.teladm = teladm;
        this.edadadm = edadadm;
        this.codadm = codadm;
    }

    public DAdministrador(String usuario,String tipo,String nombreusuario,String contraseña){
        super(usuario, tipo, nombreusuario, contraseña);
    }
    public String getNombadm() {
        return nombadm;
    }

    public void setNombadm(String nombadm) {
        this.nombadm = nombadm;
    }

    public String getDiradm() {
        return diradm;
    }

    public void setDiradm(String diradm) {
        this.diradm = diradm;
    }

    public String getFechanacadm() {
        return fechanacadm;
    }

    public void setFechanacadm(String fechanacadm) {
        this.fechanacadm = fechanacadm;
    }

    public String getLugarnacadm() {
        return lugarnacadm;
    }

    public void setLugarnacadm(String lugarnacadm) {
        this.lugarnacadm = lugarnacadm;
    }

    public String getEstadocadmm() {
        return estadocadmm;
    }

    public void setEstadocadmm(String estadocadmm) {
        this.estadocadmm = estadocadmm;
    }

    public String getSexoadm() {
        return sexoadm;
    }

    public void setSexoadm(String sexoadm) {
        this.sexoadm = sexoadm;
    }

    public String getCorradm() {
        return corradm;
    }

    public void setCorradm(String corradm) {
        this.corradm = corradm;
    }

    public String getUbiadm() {
        return ubiadm;
    }

    public void setUbiadm(String ubiadm) {
        this.ubiadm = ubiadm;
    }

    public long getCcadm() {
        return ccadm;
    }

    public void setCcadm(long ccadm) {
        this.ccadm = ccadm;
    }

    public long getTeladm() {
        return teladm;
    }

    public void setTeladm(long teladm) {
        this.teladm = teladm;
    }

    public long getEdadadm() {
        return edadadm;
    }

    public void setEdadadm(long edadadm) {
        this.edadadm = edadadm;
    }

    public long getCodadm() {
        return codadm;
    }

    public void setCodadm(long codadm) {
        this.codadm = codadm;
    }

    
}
