/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author panamericana
 */
public class DSolicitudes implements ISolicitudes{
    
        private String nombreAsp;
	private long codigo;
	private String solicitud;
	private String respuesta;
	private long codigoSolicitud;
        
	public DSolicitudes(String nombreEst,long codigo,long codigoSolicitud, String solicitud, String respuesta) {
		this.nombreAsp=nombreAsp;
		this.codigo=codigo;
		this.solicitud=solicitud;
		this.respuesta=respuesta;
		this.codigoSolicitud=codigoSolicitud;
	}
	
    @Override
	public long getCodigoSolicitud() {
		return codigoSolicitud;
	}

    @Override
	public void setCodigoSolicitud(long codigoSolicitud) {
		this.codigoSolicitud = codigoSolicitud;
	}

    @Override
	public String getNombreAsp() {
		return nombreAsp;
	}
    @Override
	public void setNombre(String nombre) {
		this.nombreAsp = nombre;
	}
    @Override
	public String getSolicitud() {
		return solicitud;
	}
    @Override
	public void setSolicitud(String asunto) {
		this.solicitud = asunto;
	}
    @Override
	public String getRespuesta() {
		return respuesta;
	}
    @Override
	public void setRespuesta(String contenido) {
		this.respuesta = contenido;
	}
	@Override
	public String toString() {
		return "Solicitudes [nombre=" + nombreAsp +", Codigo="+codigo+ ", asunto=" + solicitud
				+ ", Respuesta=" + respuesta + "]";
	}
    @Override
	public long getCodigo() {
		// TODO Auto-generated method stub
		return codigo;
	}   
}
