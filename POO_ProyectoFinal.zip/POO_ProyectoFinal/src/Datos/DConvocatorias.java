/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author panamericana
 */
public class DConvocatorias implements IConvocatorias{
    private String nomconv,nomreemp,direccionemp,fechaconv,ciudadconv,profeconv,expeconv,idioconv;
    private long telemp,salario,vacantes;

    public DConvocatorias(String nomconv, String nomreemp, String direccionemp, String ciudadconv, long vacantes, String profeconv, String expeconv, String idioconv, String fechaconv, long telemp, long salario) {
        this.nomconv = nomconv;
        this.nomreemp = nomreemp;
        this.direccionemp = direccionemp;
        this.ciudadconv = ciudadconv;
        this.vacantes = vacantes;
        this.profeconv = profeconv;
        this.expeconv = expeconv;
        this.idioconv = idioconv;
        this.fechaconv = fechaconv;
        this.telemp = telemp;
        this.salario = salario;
    }

    @Override
    public String getNomconv() {
        return nomconv;
    }

    @Override
    public void setNomconv(String nomconv) {
        this.nomconv = nomconv;
    }

    @Override
    public String getNomreemp() {
        return nomreemp;
    }

    @Override
    public void setNomreemp(String nomreemp) {
        this.nomreemp = nomreemp;
    }

    @Override
    public String getDireccionemp() {
        return direccionemp;
    }

    @Override
    public void setDireccionemp(String direccionemp) {
        this.direccionemp = direccionemp;
    }

    @Override
    public String getCiudadconv() {
        return ciudadconv;
    }

    @Override
    public void setCiudadconv(String ciudadconv) {
        this.ciudadconv = ciudadconv;
    }

    @Override
    public long getVacantes() {
        return vacantes;
    }

    @Override
    public void setVacantes(long vacantes) {
        this.vacantes = vacantes;
    }

    

    @Override
    public String getProfeconv() {
        return profeconv;
    }

    @Override
    public void setProfeconv(String profeconv) {
        this.profeconv = profeconv;
    }

    @Override
    public String getExpeconv() {
        return expeconv;
    }

    @Override
    public void setExpeconv(String expeconv) {
        this.expeconv = expeconv;
    }

    @Override
    public String getIdioconv() {
        return idioconv;
    }

    @Override
    public void setIdioconv(String idioconv) {
        this.idioconv = idioconv;
    }

    @Override
    public String getFechaconv() {
        return fechaconv;
    }

    @Override
    public void setFechaconv(String fechaconv) {
        this.fechaconv = fechaconv;
    }

   

    @Override
    public long getTelemp() {
        return telemp;
    }

    @Override
    public void setTelemp(long telemp) {
        this.telemp = telemp;
    }

    @Override
    public long getSalario() {
        return salario;
    }

    @Override
    public void setSalario(long salario) {
        this.salario = salario;
    }
}
