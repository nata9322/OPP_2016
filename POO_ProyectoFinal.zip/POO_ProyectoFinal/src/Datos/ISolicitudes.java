/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.Serializable;

/**
 *
 * @author Castillo
 */
public interface ISolicitudes extends Serializable {

    long getCodigo();

    long getCodigoSolicitud();

    String getNombreAsp();

    String getRespuesta();

    String getSolicitud();

    void setCodigoSolicitud(long codigoSolicitud);

    void setNombre(String nombre);

    void setRespuesta(String contenido);

    void setSolicitud(String asunto);

    String toString();
    
}
