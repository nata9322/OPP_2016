package Logica;

import Datos.DEmpresa;
import Datos.Usuario;
import java.io.*;
import java.net.Socket;
import java.util.logging.*;

public class Login extends Thread {

    protected Socket sk;
    protected DataOutputStream dos;
    protected ObjectInputStream dis;
    private final String user;
    private final String rol;
    private final String password;
    private Usuario us;
    private DEmpresa emp;

    public Login(String user, String password, String rol) {
        this.user = user;
        this.password = password;
        this.rol = rol;
    }

    @Override
    public void run() {
        try {
            sk = new Socket("localhost", 10578);
            dos = new DataOutputStream(sk.getOutputStream());
            dis = new ObjectInputStream(sk.getInputStream());
            if ("persona".equals(rol)) {
                // envio de datos
                dos.writeUTF(rol);
                dos.writeUTF(user);
                dos.writeUTF(password);
                // recepcion de datos
                setUs((Usuario) dis.readObject());
            }
            if ("empresa".equals(rol)) {
                // envio de datos
                dos.writeUTF(rol);
                dos.writeUTF(user);
                // recepcion de datos
                setEmp((DEmpresa) dis.readObject());
            }
            dis.close();
            dos.close();
            sk.close();
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * @return the us
     */
    public Usuario getUs() {
        return us;
    }

    /**
     * @param us the us to set
     */
    public void setUs(Usuario us) {
        this.us = us;
    }

    /**
     * @return the emp
     */
    public DEmpresa getEmp() {
        return emp;
    }

    /**
     * @param emp the emp to set
     */
    public void setEmp(DEmpresa emp) {
        this.emp = emp;
    }
}
