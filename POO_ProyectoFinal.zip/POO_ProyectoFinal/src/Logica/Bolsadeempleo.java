/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Datos.DAdministrador;
import Datos.DAspirante;
import Datos.DConvocatorias;
import Datos.DEmpresa;
import Datos.DSolicitudes;
import Datos.Usuario;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import com.csvreader.CsvReader;
import java.util.Scanner;

public class Bolsadeempleo {

    ArrayList<DAspirante> as = new ArrayList<DAspirante>();//Lista aspirantes
    ArrayList<DAdministrador> ad = new ArrayList<DAdministrador>(); //Lista Administadores
    ArrayList<DConvocatorias> conv = new ArrayList<DConvocatorias>(); //Lista cnvocatorias
    ArrayList<DEmpresa> emp = new ArrayList<DEmpresa>(); //Lista empresas
    ArrayList<DSolicitudes> soli = new ArrayList<DSolicitudes>();
    ArrayList<Usuario> us = new ArrayList<Usuario>();

    private Scanner in;
//private FileWriter fw;
    private PrintWriter outputFile;
    private PrintWriter outputUsu;
    private PrintWriter outputConv;
    private PrintWriter outputEmp;
    private PrintWriter outputAdm;
    private PrintWriter outputSoli;

    public Bolsadeempleo() {

//        this.aspi = aspi;
    }

    public ArrayList<DAspirante> getAs() {
        return as;
    }

    public ArrayList<DAdministrador> getAd() {
        return ad;
    }

    public ArrayList<DConvocatorias> getConv() {
        return conv;
    }

    public ArrayList<DEmpresa> getEmp() {
        return emp;
    }

    public ArrayList<DSolicitudes> getSoli() {
        return soli;
    }

    public ArrayList<Usuario> getUs() {
        return us;
    }

    public void aspirante(String nomasp, String dirasp, String fechanaci, String lugarnaci, String estadocasp, String sexoasp, String corrasp, String ubiasp, String idiomaasp, String profasp, String fechapubasp, String expasp, String dexpasp, String reffasp, String refpasp, long ccasp, long telasp, long edadasp, String usuario, String tipo, String nombreusuario, String contraseña) {
        as.add(new DAspirante(nomasp, dirasp, fechanaci, lugarnaci, estadocasp, sexoasp, corrasp, ubiasp, idiomaasp, profasp, fechapubasp, expasp, dexpasp, reffasp, refpasp, ccasp, telasp, edadasp, usuario, tipo, nombreusuario, contraseña));

        for (int i = 0; i < as.size(); i++) {
            System.out.println(as.get(i).getEstadocasp().toString());
        }
    }

    public void usuario(String usuario, String tipo, String nombreusuario, String contraseña) {
        us.add(new Usuario(usuario, tipo, nombreusuario, contraseña));

        for (int i = 0; i < us.size(); i++) {
            System.out.println(us.get(i).getUsuario().toString());
        }
    }

    public void crearconv(String nomconv, String nomreemp, String direccionemp, String ciudadconv, long vacantes, String profeconv, String expeconv, String idioconv, String fechaconv, long telemp, long salario) {
        conv.add(new DConvocatorias(nomconv, nomreemp, direccionemp, ciudadconv, vacantes, profeconv, expeconv, idioconv, fechaconv, telemp, salario));

        for (int i = 0; i < conv.size(); i++) {
            System.out.println(conv.get(i).getExpeconv().toString());
        }
    }

    public void crearemp(String nomemp, String diremp, String coremp, String ubiemp, String pagwemp, String descrip, int codemp, int nit, int telemp) {
        emp.add(new DEmpresa(nomemp, diremp, coremp, ubiemp, pagwemp, descrip, codemp, nit, telemp));
        for (int i = 0; i < emp.size(); i++) {
            System.out.println(emp.get(i).getCoremp());
        }
    }

    public void crearadm(String nombadm, String diradm, String fechanacadm, String lugarnacadm, String estadocadmm, String sexoadm, String corradm, String ubiadm, long ccadm, long teladm, long edadadm, long codadm, String usuario, String tipo, String nombreusuario, String contraseña) {
        ad.add(new DAdministrador(nombadm, diradm, fechanacadm, lugarnacadm, estadocadmm, sexoadm, corradm, ubiadm, ccadm, teladm, edadadm, codadm, usuario, tipo, nombreusuario, contraseña));
        for (int i = 0; i < ad.size(); i++) {
            System.out.println(ad.get(i).getEstadocadmm().toString());
        }
    }

    public void crearsoli(String nombreEst, long codigo, long codigoSolicitud, String solicitud, String respuesta) {
        soli.add(new DSolicitudes(nombreEst, codigo, codigoSolicitud, solicitud, respuesta));

    }

    public void crearcvsasp() throws IOException {

        String sFichero = "Aspirantes.csv";
        File fichero = new File(sFichero);
        FileWriter fw = new FileWriter("Aspirantes.csv");
        if (fichero.exists()) {

            outputFile = new PrintWriter(fw);
            // ',' divides the word into columns
            outputFile.println("CEDULA,NOMBRES COMPLETOS,DIRECCION,TELEFONO,FECHA NACIMIENTO,LUGAR NACIMIENTO,ESTADO CIVIL,EDAD,SEXO,CORREO,UBICACION,IDIOMAS, PROFESION,FECHA,EXPERIENCIA,DESCRIPCION EXPERIENCIA,REFERENCIAS FAMILIARES, REFERENCIAS PERSONALES,USUARIO,TIPO,NOMBRE USUARIO,CONTRASEÑA");// first row first column

            for (int t = 0; t < as.size(); t++) {
                outputFile.println(as.get(t).getCcasp() + "," + as.get(t).getNomasp() + "," + as.get(t).getDirasp() + "," + as.get(t).getTelasp() + "," + as.get(t).getFechanaci() + "," + as.get(t).getLugarnaci() + "," + as.get(t).getEstadocasp() + "," + as.get(t).getEdadasp() + "," + as.get(t).getSexoasp() + "," + as.get(t).getCorrasp() + "," + as.get(t).getUbiasp() + "," + as.get(t).getIdiomaasp() + "," + as.get(t).getProfasp() + "," + as.get(t).getFechapubasp() + "," + as.get(t).getExpasp() + "," + as.get(t).getDexpasp() + "," + as.get(t).getReffasp() + "," + as.get(t).getRefpasp() + "," + as.get(t).getUsuario() + "," + as.get(t).getTipo() + "," + as.get(t).getNombreusuario() + "," + as.get(t).getContraseña());

            }
            //Flush the output to the file
            outputFile.flush();

            //Close the Print Writer
            outputFile.close();

            //Close the File Writer
            fw.close();
        }

    }

    public void cargararchivoasp() {

        try {

            CsvReader aspirantes = new CsvReader("Aspirantes.csv");
            aspirantes.readHeaders();

            while (aspirantes.readRecord()) {
                String nomasp = aspirantes.get(1);
                String dirasp = aspirantes.get(2);
                String fechanaci = aspirantes.get(4);
                String lugarnaci = aspirantes.get(5);
                String estadocasp = aspirantes.get(6);
                String sexoasp = aspirantes.get(8);
                String corrasp = aspirantes.get(9);
                String ubiasp = aspirantes.get(10);
                String idiomaasp = aspirantes.get(11);
                String fechapubasp = aspirantes.get(13);
                String expasp = aspirantes.get(14);
                String dexpasp = aspirantes.get(15);
                String reffasp = aspirantes.get(16);
                String refpasp = aspirantes.get(17);
                String ccasp = aspirantes.get(0);
                String telasp = aspirantes.get(3);
                String edadasp = aspirantes.get(7);
                String usuario = aspirantes.get(18);
                String tipo = aspirantes.get(19);
                String nombreusuario = aspirantes.get(20);
                String contraseña = aspirantes.get(21);
                String profasp = aspirantes.get(12);

                long ccaspi = Long.parseLong(ccasp);
                long telaspi = Long.parseLong(telasp);
                long edadaspi = Long.parseLong(edadasp);

                as.add(new DAspirante(nomasp, dirasp, fechanaci, lugarnaci, estadocasp, sexoasp, corrasp, ubiasp, idiomaasp, profasp, fechapubasp, expasp, dexpasp, reffasp, refpasp, ccaspi, telaspi, edadaspi, usuario, tipo, nombreusuario, contraseña));

            }

            aspirantes.close();

            for (DAspirante asp : as) {

                System.out.println(asp.getCcasp() + " : " + asp.getNomasp() + " " + asp.getCorrasp() + " - " + asp.getIdiomaasp());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void crearcvsusu() throws IOException {

        String u = "Usuarios.csv";
        File f = new File(u);
        FileWriter usua = new FileWriter("Usuarios.csv");
        if (f.exists()) {

            outputUsu = new PrintWriter(usua);
            // ',' divides the word into columns
            outputUsu.println("USUARIO,TIPO,NOMBRE USUARIO,PASSWORD");// first row first column

            for (int t = 0; t < us.size(); t++) {
                outputUsu.println(us.get(t).getUsuario() + "," + us.get(t).getTipo() + "," + us.get(t).getNombreusuario() + "," + us.get(t).getContraseña());

            }
            //Flush the output to the file
            outputUsu.flush();

            //Close the Print Writer
            outputUsu.close();

            //Close the File Writer
            usua.close();
        }

    }

    public void cargararchivousu() {

        try {

            CsvReader usuarios = new CsvReader("Usuarios.csv");
            usuarios.readHeaders();

            while (usuarios.readRecord()) {
                String usuario = usuarios.get(0);
                String tipo = usuarios.get(1);
                String nombreusuario = usuarios.get(2);
                String contraseña = usuarios.get(3);

                us.add(new Usuario(usuario, tipo, nombreusuario, contraseña));
            }

            usuarios.close();

            for (Usuario usu : us) {

                System.out.println(usu.getUsuario() + " : " + usu.getTipo() + " " + usu.getNombreusuario() + " - " + usu.getContraseña());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void crearcvsconv() throws IOException {

        String s1 = "Convocatorias.csv";
        File f1 = new File(s1);
        FileWriter c1 = new FileWriter("Convocatorias.csv");
        if (f1.exists()) {

            outputConv = new PrintWriter(c1);
            // ',' divides the word into columns
            outputConv.println("NOMBRE CONVOCATORIA, NOMBRE EMPRESA, DIRECCION EMPRESA, CIUDAD, VACANTES, PROFESION, EXPERIENCIA, IDIOMA, FECHA, TELEFONO, SALARIO");
            for (int t = 0; t < conv.size(); t++) {
                outputConv.println(conv.get(t).getNomconv() + "," + conv.get(t).getNomreemp() + "," + conv.get(t).getDireccionemp() + "," + conv.get(t).getCiudadconv() + "," + conv.get(t).getVacantes() + "," + conv.get(t).getProfeconv() + "," + conv.get(t).getExpeconv() + "," + conv.get(t).getIdioconv() + "," + conv.get(t).getFechaconv() + "," + conv.get(t).getTelemp() + "," + conv.get(t).getSalario());

            }
            //Flush the output to the file
            outputConv.flush();

            //Close the Print Writer
            outputFile.close();

            //Close the File Writer
            c1.close();
        }

    }

    public void cargararchivoconv() {

        try {

            CsvReader convocatorias = new CsvReader("Convocatorias.csv");
            convocatorias.readHeaders();

            while (convocatorias.readRecord()) {

                String nomconv = convocatorias.get(0);
                String nomreemp = convocatorias.get(1);
                String direccionemp = convocatorias.get(2);
                String ciudadconv = convocatorias.get(3);
                String vacantes = convocatorias.get(4);
                String profeconv = convocatorias.get(5);
                String expeconv = convocatorias.get(6);
                String idioconv = convocatorias.get(7);
                String fechaconv = convocatorias.get(8);
                String telemp = convocatorias.get(9);
                String salario = convocatorias.get(10);

                long ltelemp = Long.parseLong(telemp);
                long lsalario = Long.parseLong(salario);
                long lvacantes = Long.parseLong(vacantes);
                conv.add(new DConvocatorias(nomconv, nomreemp, direccionemp, ciudadconv, lvacantes, profeconv, expeconv, idioconv, fechaconv, ltelemp, lsalario));

            }

            convocatorias.close();

            for (DConvocatorias convo : conv) {

                System.out.println(convo.getCiudadconv() + " : " + convo.getNomconv() + " " + convo.getNomreemp() + " - " + convo.getSalario());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void crearcvsemp() throws IOException {

        String s2 = "Empresas.csv";
        File f2 = new File(s2);
        FileWriter e1 = new FileWriter("Empresas.csv");
        if (f2.exists()) {

            outputEmp = new PrintWriter(e1);
            // ',' divides the word into columns
            outputEmp.println("NOMBRE,DIRECCION,CORREO,UBICACIÓN,PÁGINA WEB,DESCRIPCIÓN,CODIGO,NIT,TELÉFONO");
            for (int t = 0; t < emp.size(); t++) {
                outputEmp.println(emp.get(t).getNomemp() + "," + emp.get(t).getDiremp() + "," + emp.get(t).getCoremp() + "," + emp.get(t).getUbiemp() + "," + emp.get(t).getPagwemp() + "," + emp.get(t).getDescrip() + "," + emp.get(t).getCodemp() + "," + emp.get(t).getNit() + "," + emp.get(t).getTelemp());

            }
            //Flush the output to the file
            outputEmp.flush();

            //Close the Print Writer
            outputEmp.close();

            //Close the File Writer
            e1.close();
        }

    }

    public void cargararchivoemp() {

        try {

            CsvReader empr = new CsvReader("Empresas.csv");
            empr.readHeaders();

            while (empr.readRecord()) {

                String nomemp = empr.get(0);
                String diremp = empr.get(1);
                String coremp = empr.get(2);
                String ubiemp = empr.get(3);
                String pagwemp = empr.get(4);
                String descrip = empr.get(5);
                String codemp = empr.get(6);
                String nit = empr.get(7);
                String telemp = empr.get(8);
                int lcodemp = Integer.parseInt(codemp);
                int lnit = Integer.parseInt(nit);
                int ltelemp = Integer.parseInt(telemp);

                emp.add(new DEmpresa(nomemp, diremp, coremp, ubiemp, pagwemp, descrip, lcodemp, lnit, ltelemp));
            }

            empr.close();

            for (DEmpresa empre : emp) {

                System.out.println(empre.getNomemp() + " : " + empre.getDiremp() + " " + empre.getCoremp() + " - " + empre.getUbiemp());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void crearcvsadm() throws IOException {

        String s3 = "Administradores.csv";
        File f3 = new File(s3);
        FileWriter e2 = new FileWriter("Administradores.csv");
        if (f3.exists()) {

            outputAdm = new PrintWriter(e2);
            // ',' divides the word into columns
            outputAdm.println("NOMBRE,DIRECCION,FECHA NACIMIENTO,LUGAR NACIMIENTO,ESTADO CIVIL,SEXO,CORREO,UBICACIÓN, CEDULA, TELEFONO,EDAD,CODIGO, USUARIO, TIPO,NOMBRE USUARIO, CONTRASEÑA");
            for (int t = 0; t < ad.size(); t++) {
                outputAdm.println(ad.get(t).getNombadm() + "," + ad.get(t).getDiradm() + "," + ad.get(t).getFechanacadm() + "," + ad.get(t).getLugarnacadm() + "," + ad.get(t).getEstadocadmm() + "," + ad.get(t).getSexoadm() + "," + ad.get(t).getCorradm() + "," + ad.get(t).getUbiadm() + "," + ad.get(t).getCcadm() + "," + ad.get(t).getTeladm() + "," + ad.get(t).getEdadadm() + "," + ad.get(t).getCodadm() + "," + ad.get(t).getUsuario() + "," + ad.get(t).getTipo() + "," + ad.get(t).getNombreusuario() + "," + ad.get(t).getContraseña());

            }
            //Flush the output to the file
            outputAdm.flush();

            //Close the Print Writer
            outputAdm.close();

            //Close the File Writer
            e2.close();
        }

    }

    public void cargararchivoadm() {

        try {

            CsvReader admin = new CsvReader("Administradores.csv");
            admin.readHeaders();

            while (admin.readRecord()) {

                String nombadm = admin.get(0);
                String diradm = admin.get(1);
                String fechanacadm = admin.get(2);
                String lugarnacadm = admin.get(3);
                String estadocadmm = admin.get(4);
                String sexoadm = admin.get(5);
                String corradm = admin.get(6);
                String ubiadm = admin.get(7);
                String ccadm = admin.get(8);
                String teladm = admin.get(9);
                String edadadm = admin.get(10);
                String codadm = admin.get(11);
                String usuario = admin.get(12);
                String tipo = admin.get(13);
                String nombreusuario = admin.get(14);
                String contraseña = admin.get(15);
                long lcodadm = Long.parseLong(codadm);
                long ledadadmin = Long.parseLong(edadadm);
                long lteladm = Long.parseLong(teladm);
                long lccadm = Long.parseLong(ccadm);
                ad.add(new DAdministrador(nombadm, diradm, fechanacadm, lugarnacadm, estadocadmm, sexoadm, corradm, ubiadm, lccadm, lteladm, ledadadmin, lcodadm, usuario, tipo, nombreusuario, contraseña));
            }

            admin.close();

            for (DAdministrador adm : ad) {

                System.out.println(adm.getNombadm() + " : " + adm.getDiradm() + " " + adm.getCorradm() + " - " + adm.getUbiadm());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void crearcvssol() throws IOException {

        String s4 = "Solicitudes.csv";
        File f4 = new File(s4);
        FileWriter e4 = new FileWriter("Solicitudes.csv");
        if (f4.exists()) {

            outputSoli = new PrintWriter(e4);
            // ',' divides the word into columns
            outputSoli.println("NOMBRE,CODIGO,CODIGO SOLICITUD,SOLICITUD,RESPUESTA");
            for (int t = 0; t < soli.size(); t++) {
                outputSoli.println(soli.get(t).getNombreAsp() + "," + soli.get(t).getCodigo() + "," + soli.get(t).getCodigoSolicitud() + "," + soli.get(t).getSolicitud() + "," + soli.get(t).getRespuesta());

            }
            //Flush the output to the file
            outputSoli.flush();

            //Close the Print Writer
            outputSoli.close();

            //Close the File Writer
            e4.close();
        }

    }

    public void cargararchivosol() {

        try {

            CsvReader sol = new CsvReader("Solicitudes.csv");
            sol.readHeaders();

            while (sol.readRecord()) {

                String nombreEst = sol.get(0);
                String codigo = sol.get(1);
                String codigoSolicitud = sol.get(2);
                String solicitud = sol.get(3);
                String respuesta = sol.get(4);
                long cod = Long.parseLong(codigo);
                long codsol = Long.parseLong(codigoSolicitud);

                soli.add(new DSolicitudes(nombreEst, cod, codsol, solicitud, respuesta));
            }

            sol.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
