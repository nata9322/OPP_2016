/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servidor;

import Datos.DEmpresa;
import Datos.IEmpresa;
import Datos.Usuario;
import com.csvreader.CsvReader;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jspar
 */
public class ServidorHilo extends Thread {

    private Socket socket;
    private ObjectOutputStream dos;
    private DataInputStream dis;

    public ServidorHilo(Socket socket) {
        this.socket = socket;
        try {
            dos = new ObjectOutputStream(socket.getOutputStream());
            dis = new DataInputStream(socket.getInputStream());
        } catch (IOException ex) {
            Logger.getLogger(ServidorHilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void desconnectar() {
        try {
            socket.close();
        } catch (IOException ex) {
            Logger.getLogger(ServidorHilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {
        String rol;
        String user;
        String password;
        try {
            rol = dis.readUTF();
            if ("persona".equals(rol)) {
                user = dis.readUTF();
                password = dis.readUTF();
                Usuario us = userCSV(user, password);
                dos.writeObject(us);
            }
            if ("empresa".equals(rol)) {
                user = dis.readUTF();
               IEmpresa emp = empresaCSV(user);
                dos.writeObject(emp);
            }

        } catch (IOException ex) {
            Logger.getLogger(ServidorHilo.class.getName()).log(Level.SEVERE, null, ex);
        }
        desconnectar();
    }

    private Usuario userCSV(String user, String password) throws FileNotFoundException, IOException {
        CsvReader users = new CsvReader("Usuarios.csv");
        users.readHeaders();
        while (users.readRecord()) {
            if (user.equals(users.get("USUARIO"))) {
                if (password.equals(users.get("PASSWORD"))) {
                    Usuario u = new Usuario(users.get(0), users.get(1), users.get(2), users.get(3));
                    return u;
                }
            }
        }
        return null;
    }

    private DEmpresa empresaCSV(String user) throws FileNotFoundException, IOException {
        CsvReader empresa = new CsvReader("Empresas.csv");
        empresa.readHeaders();
        while (empresa.readRecord()) {
            if (user.equals(empresa.get("NOMBRE"))) {
                DEmpresa emp = new DEmpresa(empresa.get(0), empresa.get(1), empresa.get(2), empresa.get(3), empresa.get(4), empresa.get(5), Integer.parseInt(empresa.get(6)), Integer.parseInt(empresa.get(7)), Integer.parseInt(empresa.get(8)));
                return emp;
            }
        }
        return null; //To change body of generated methods, choose Tools | Templates.
    }
}
