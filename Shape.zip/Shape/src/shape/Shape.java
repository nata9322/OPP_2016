
package shape;


public abstract class Shape {
    
    double numSides;

    public double getNumSides() {
        return numSides;
    }

    public void setNumSides(int numSides) {
        this.numSides = numSides;
    }
      
    
    public abstract double getArea();
    
    public abstract double getPerimeter();
    

    
    
}
