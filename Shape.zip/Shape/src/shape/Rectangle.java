
package shape;

public class Rectangle extends Shape {
    double widgth;
    double height;
    
    public Rectangle(double widgth, double heigth){
        this.widgth=widgth;
        this.height=heigth;
        
    }

    public double getWidgth() {
        return widgth;
    }

    public void setWidgth(double widgth) {
        this.widgth = widgth;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    } 

    @Override
    public double getArea() {
        return widgth*height;
    }

    @Override
    public double getPerimeter() {
        return 2*(widgth+height);
    }
    
    
    
    
}
