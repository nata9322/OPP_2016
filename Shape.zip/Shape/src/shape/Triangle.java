
package shape;

public class Triangle extends Shape {
    double widgth;
    double height;

    public Triangle(double widgth, double heigth){
        this.widgth=widgth;
        this.height=heigth;
        
    }
    public double getWidgth() {
        return widgth;
    }

    public void setWidgth(double widgth) {
        this.widgth = widgth;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }
    @Override
    public double getArea() {
        return (widgth*height)/2;
    }

    @Override
    public double getPerimeter() {
        return widgth+2*Math.sqrt(Math.pow(widgth/2,2)+Math.pow(height,2));
    }
}
