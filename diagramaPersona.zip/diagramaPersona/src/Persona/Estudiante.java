
package Persona;


public class Estudiante extends Persona {
    int grado;
    char grupo;
    
    public void estudiar(){
    }
    
}
