
package Persona;


public class Profesor extends Empleado {
    String carrera;
    
    public void enseñar(){
    }
    
}
