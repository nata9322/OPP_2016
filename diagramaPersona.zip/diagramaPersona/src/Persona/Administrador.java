
package Persona;


public class Administrador extends Empleado {
    String puesto;
    
    public void administrar(){
    }
    
}
