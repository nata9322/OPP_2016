
package Persona;


public class Persona {
    
    String nombre;
    String domicilio;
    String horario;
    
    public void asistir(){
    }

    
    public static void main(String[] args) {
        
    }
    
}
