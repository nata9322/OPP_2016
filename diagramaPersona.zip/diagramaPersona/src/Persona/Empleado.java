
package Persona;

public class Empleado extends Persona {
    String jefe;
    public void cobrar(){
    }
    
}
