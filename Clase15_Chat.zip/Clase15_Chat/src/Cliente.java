
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario11
 */
public class Cliente {
    
      public static void main(String[] args) throws IOException {
        Socket cliente =new Socket("localhost",8000);
            
        BufferedReader entrada =
             new BufferedReader ( new InputStreamReader(cliente.getInputStream()));
    
    PrintWriter salida = new PrintWriter (cliente.getOutputStream(),true);
    
    BufferedReader teclado=new BufferedReader
            (new InputStreamReader(System.in));
          while(true){
     System.out.println  ("mensaje a enviar:");
     String mensaje =teclado. readLine();
     salida.println(mensaje);
     
     String llego = entrada.readLine();
     System.out.println(llego);
    } 
}
}
