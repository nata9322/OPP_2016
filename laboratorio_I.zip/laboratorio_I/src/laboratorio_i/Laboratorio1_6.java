package laboratorio_i;

import java.util.Scanner;

public class Laboratorio1_6 {

    public static void menu(String [][] sillasEjecutivo,String [][] sillasEconomica ){
        System.out.println("Bienvenido");
        System.out.println("1. Asignacion de sillas a pasajeros");
        System.out.println("2. Contar sillas ejecutivas ocupadas");
        System.out.println("3. Localizar una silla economica disponible");
        System.out.println("4. Anular reserva");
        System.out.println("5. Contar el número de puestos disponibles en venta en la clase economcia");
        System.out.println("6. Coincidencias de nombres en clase economica ");
        System.out.println("7. Salir");
        Scanner entradaMenu= new Scanner(System.in);
        int opcionMenu= entradaMenu.nextInt();
        if(opcionMenu==1){
            AsiganacionSilla(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==2){
            ContarSillasEjecutivas(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==3){
            LocalizarSillaEconomicaDisponible(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==4){
            AnularReserva(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==5){
            SillasDisponibleEconomica(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==6){
            CoincidenciasNombresEconomica(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==7){
            System.exit(0); 
        }
        else{
            System.out.println("opcion incorrecta");
                    }
    }
    public static void AsiganacionSilla(String [][] sillasEjecutivo,String [][] sillasEconomica){
        System.out.println("Seleccione la clase");
        System.out.println("1. Ejecutiva");
        System.out.println("2. economica");
        Scanner entradaMenu= new Scanner(System.in);
        int opcionMenu= entradaMenu.nextInt();
        if(opcionMenu==1){
            AsignacionSillaEjecutivo(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==2){
            AsiganacionSillaEconomica(sillasEjecutivo,sillasEconomica);
        }  
    }
    public static void AsignacionSillaEjecutivo(String [][] sillasEjecutivo,String [][] sillasEconomica){
        System.out.println("Ingrese nombre del pasajero");
        Scanner leerNombre= new Scanner(System.in);
        String nombre= leerNombre.nextLine();
        System.out.println("Ingrese la cedula del pasajero");
        Scanner leerCedula= new Scanner(System.in);
        String cedula= leerCedula.nextLine();
        System.out.println("Seleccione la ubicacion");
        System.out.println("1. Ventana");
        System.out.println("2. Pasillo");
        Scanner entradaMenu= new Scanner(System.in);
        int opcionMenu= entradaMenu.nextInt();
        if(opcionMenu==1){
            int i=0;
        while(i<8){
            if (sillasEjecutivo[0][i]==null){
                sillasEjecutivo[0][i]=nombre;
                sillasEjecutivo[1][i]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                i=i+4;
                
            }
        }
        i=3;
        while(i<8){
            if (sillasEjecutivo[0][i]==null){
                sillasEjecutivo[0][i]=nombre;
                sillasEjecutivo[1][i]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                i=i+4;
                
            }
        }
        System.out.println("Las ventanas en clase ejecutivo estan llenas");
        menu(sillasEjecutivo,sillasEconomica);
        }
        
        if(opcionMenu==2){
            int j=1;
            while(j<8){
                if (sillasEjecutivo[0][j]==null){
                sillasEjecutivo[0][j]=nombre;
                sillasEjecutivo[1][j]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                j=j+4;
                
            }
            }
            j=2;
        while(j<8){
            if (sillasEjecutivo[0][j]==null){
                sillasEjecutivo[0][j]=nombre;
                sillasEjecutivo[1][j]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                j=j+4;
                
            }
        }
        System.out.println("Las sillas en el pasillo estan ocupadas");
        menu(sillasEjecutivo,sillasEconomica);
        }
        
        
        
    }
    public static void AsiganacionSillaEconomica(String [][] sillasEjecutivo,String [][] sillasEconomica){
        System.out.println("Ingrese nombre del pasajero");
        Scanner leerNombre= new Scanner(System.in);
        String nombre= leerNombre.nextLine();
        System.out.println("1Ingrese la cedula del pasajero");
        Scanner leerCedula= new Scanner(System.in);
        String cedula= leerCedula.nextLine();
        System.out.println("Seleccione la ubicacion");
        System.out.println("1. Ventana");
        System.out.println("2. Centro");
        System.out.println("3. Pasillo");
        Scanner entradaMenu= new Scanner(System.in);
        int opcionMenu= entradaMenu.nextInt();
        if(opcionMenu==1){
            int i=0;
        while(i<42){
            if (sillasEconomica[0][i]==null){
                sillasEconomica[0][i]=nombre;
                sillasEconomica[1][i]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                i=i+6;
                
            }
        }
        i=5;
        while(i<42){
            if (sillasEconomica[0][i]==null){
                sillasEconomica[0][i]=nombre;
                sillasEconomica[1][i]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                i=i+6;
                
            }
        }
        System.out.println("Las ventanas en clase economica estan llenas");
        menu(sillasEjecutivo,sillasEconomica);            
        }
        if(opcionMenu==2){
            int j=1;
        while(j<42){
            if (sillasEconomica[0][j]==null){
                sillasEconomica[0][j]=nombre;
                sillasEconomica[1][j]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                j=j+3;
                
            }
        }
        System.out.println("Las sillas del centro estan llenas");
        menu(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==3){
            int k=2;
        while(k<42){
            if (sillasEconomica[0][k]==null){
                sillasEconomica[0][k]=nombre;
                sillasEconomica[1][k]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                k=k+6;
                
            }
        }
        k=3;
        while(k<42){
            if (sillasEconomica[0][k]==null){
                sillasEconomica[0][k]=nombre;
                sillasEconomica[1][k]=cedula;
                System.out.println("Pasajero asignado");
                menu(sillasEjecutivo,sillasEconomica);
            }
            else{
                k=k+6;
                
            }
        }
        System.out.println("Las sillas del pasillo en clase economica estan llenas");
        menu(sillasEjecutivo,sillasEconomica);            
        }
        
    }
    public static void ContarSillasEjecutivas(String [][] sillasEjecutivo,String [][] sillasEconomica){
        int contador=0;
        for(int i=0;i<8;i++){
            if(sillasEjecutivo[0][i]!=null){
                contador++;
            }
        }
        System.out.println("Se han ocupado: "+contador+" sillas en clase ejecutivo");
        menu(sillasEjecutivo,sillasEconomica);
    }
    public static void LocalizarSillaEconomicaDisponible(String [][] sillasEjecutivo,String [][] sillasEconomica){
        int fila;
        for(int i=0;i<42;i++){
        if(sillasEconomica[0][i]==null&&sillasEconomica[1][i]==null){
            if(i%6==0||(5+(i*6))%6==5){
                fila=(i/6)+1;
                System.out.println("Hay una silla disponible en una de las ventana en la fila "+ fila);
                menu(sillasEjecutivo,sillasEconomica);
            }
            if(i%3==1){
                fila=(i/6)+1;
                System.out.println("Hay una silla disponible en el centro de la fila "+ fila);
                menu(sillasEjecutivo,sillasEconomica);
            }
            if((2+(i*6))%6==2||(3+(i*6))%6==3){
                fila=(i/6)+1;
                System.out.println("Hay una silla disponible cerca en el pasillo en la fila  "+ fila);
                menu(sillasEjecutivo,sillasEconomica);
            }
            
            
        }
        System.out.println("Esta todo lleno");
        menu(sillasEjecutivo,sillasEconomica);
        }
    }
    public static void AnularReserva(String [][] sillasEjecutivo,String [][] sillasEconomica){
        System.out.println("¿En que clase desea anular la reserva?");
        System.out.println("1. Ejecutivo");
        System.out.println("2. Economico");
        Scanner entradaMenu= new Scanner(System.in);
        int opcionMenu= entradaMenu.nextInt();
        if(opcionMenu==1){
            System.out.println("1Ingrese la cedula del pasajero");
            Scanner leerCedula= new Scanner(System.in);
            String cedula= leerCedula.nextLine();
            for(int i=0;i<8;i++){
                if(sillasEjecutivo[1][i]==cedula){
                    sillasEjecutivo[0][i]=null;
                    sillasEjecutivo[1][i]=null;
                System.out.println("Reserva anulada");
                menu(sillasEjecutivo,sillasEconomica);
                }
                
            }
            System.out.println("No se encontro esa reserva");
            menu(sillasEjecutivo,sillasEconomica);
        }
        if(opcionMenu==2){
            System.out.println("1Ingrese la cedula del pasajero");
            Scanner leerCedula= new Scanner(System.in);
            String cedula= leerCedula.nextLine();
            for(int i=0;i<42;i++){
                if(sillasEconomica[1][i]==cedula){
                    sillasEconomica[0][i]=null;
                    sillasEconomica[1][i]=null;
                System.out.println("Reserva anulada");
                menu(sillasEjecutivo,sillasEconomica);
                }
            }
            System.out.println("No se encontro esa reserva");
            menu(sillasEjecutivo,sillasEconomica);
        }
    }
    public static void SillasDisponibleEconomica(String [][] sillasEjecutivo,String [][] sillasEconomica){
       int contador=0;
       for(int i=0;i<42;i++){
           if(sillasEconomica[0][i]==null&&sillasEconomica[1][i]==null){
           contador++;
           }
       }
       System.out.println("Se encuentra disponible en clase economica "+contador+" sillas ");
       menu(sillasEjecutivo,sillasEconomica);
       
    }
    public static void CoincidenciasNombresEconomica(String [][] sillasEjecutivo,String [][] sillasEconomica){
   for(int i=0;i<42;i++){
        for(int j=i+1;j<42;j++){
            if((sillasEconomica[0][i]==sillasEconomica[0][j])&&sillasEconomica[0][j]!=null){
                System.out.println("Se encontro dos "+sillasEconomica[0][j]+"en clase economica");
                menu(sillasEjecutivo,sillasEconomica);
            }
          }
    }
    System.out.println("No se encontraron coincidencias");
                menu(sillasEjecutivo,sillasEconomica);
    }
    public static void main(String[] args) {
        String [][] sillasEjecutivo = new String[2][8];
        String [][] sillasEconomica = new String[2][42];        
        menu(sillasEjecutivo,sillasEconomica);
        
    }
    
}

