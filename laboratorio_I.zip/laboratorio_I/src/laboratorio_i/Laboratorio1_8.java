package laboratorio_i;

import java.util.Scanner;

public class Laboratorio1_8 {

public static void menu(String [][] productos, int [][] venta, int [][] vendedores){
        System.out.println();
        System.out.println("Codigo promocional del dia: AAA...Recibe un 10% de descuento por cada venta");
        System.out.println("Nuestros vendedores:");
        System.out.println("ID: 1   Nombre: Luis   Apellido: Perez");
        System.out.println("ID: 2   Nombre: Mario  Apellido: Rodriguez");
        System.out.println();
        
        System.out.println("Seleccione una opcion:");
        System.out.println("1. Ingresar datos del producto");
        System.out.println("2. Ingrese datos de venta registrada");
        System.out.println("3. Ver vendedor con mayor cantidad de ventas");
        System.out.println("4. Ver todas las ventas realizadas por Debito");
        System.out.println("5. Ver ventas de un vendedor y un determinado producto");
        System.out.println("6. Total de ventas realizadas");
        System.out.println("7. Venta de mayor valor pagada en Tarjeta de credito ");
        System.out.println("8. SALIR");
        Scanner entradaMenu= new Scanner(System.in);
        int opcionMenu= entradaMenu.nextInt();
        if(opcionMenu==1){
             IngresarProducto(productos, venta, vendedores);
        }
        if(opcionMenu==2){
            IngresarVenta(productos, venta, vendedores);
                       
        }
        if(opcionMenu==3){
            VendedorQueMasVendio(productos, venta, vendedores);
            
        }
        if(opcionMenu==4){
            ListadoVentasDebito(productos, venta, vendedores);
        }
        if(opcionMenu==5){
           ConsultaVendedorProducto(productos, venta, vendedores);
        }
        if(opcionMenu==6){            
             TotalVentas(productos, venta, vendedores);
        }
        if(opcionMenu==7){
            MayorVentaEnTarjeta(productos, venta, vendedores);
            
        }
        if(opcionMenu==8){
            System.exit(0); 
        }
        
        
        
        
        
    }
    public static void IngresarProducto(String [][] productos, int [][] venta, int [][] vendedores){
    System.out.println();
              System.out.println("Ingrese Codigo del producto: ");
              Scanner entradaCodigoProducto= new Scanner(System.in);
              String codigo=entradaCodigoProducto.nextLine();
              System.out.println("Ingrese Descripcion del producto: ");
              Scanner entradaDescripcion= new Scanner(System.in);
              String descripcion=entradaDescripcion.nextLine();
              System.out.println("Ingrese precio del producto");
              Scanner entradaPrecio= new Scanner(System.in);
              String precio=entradaPrecio.nextLine();
              for(int i=0; i<10;i++){
                  if(productos[i][0]==null){
                      productos[i][0]=codigo;
                      productos[i][1]=descripcion;
                      productos[i][2]=precio;
                      System.out.println("Producto ingresado");
                       menu(productos, venta, vendedores);
                  }
                  
              }}
    public static void IngresarVenta(String [][] productos, int [][] venta, int [][] vendedores){
        System.out.println();
        System.out.println("Ingrese Dia");
        Scanner entradaDiaVenta= new Scanner(System.in);
        int dia= entradaDiaVenta.nextInt();
        
        System.out.println("Ingrese Mes");
        Scanner entradaMesVenta= new Scanner(System.in);
        int mes= entradaMesVenta.nextInt();
       
        System.out.println("Ingrese Anno");
        Scanner entradaAnnoVenta= new Scanner(System.in);
        int anno= entradaAnnoVenta.nextInt();
       
        System.out.println("Ingrese Hora, solo la Hora, no minutos, ni segundos");
        Scanner entradaHoraVenta= new Scanner(System.in);
        int hora= entradaHoraVenta.nextInt();
        
        System.out.println("Ingrese ID del vendedor que atendio ");
        Scanner entradaCodigoVendedor= new Scanner(System.in);
        int idVendedor= entradaCodigoVendedor.nextInt();
        
        System.out.println("Ingrese Codigo del producto: ");
        Scanner entradaCodigoProducto= new Scanner(System.in);       
        int codigoProducto= entradaCodigoProducto.nextInt();
        
        System.out.println("Ingrese Cantidades vendidas");
        Scanner entradaCantidadVenta= new Scanner(System.in);
        int cantidades= entradaCantidadVenta.nextInt();
        
        System.out.println("Ingrese forma de pago   ingrese: 0-efectivo 1-Debito  2-Tarjeta C.");
        Scanner entradaFormaDePago= new Scanner(System.in);
        int formaDePago= entradaFormaDePago.nextInt();
        
        
        for(int i=0; i<10;i++){
            if(venta[i][0]!=0){
                venta[i][0]=dia;
                venta[i][1]=mes;
                venta[i][2]=anno;
                venta[i][3]=hora;
                venta[i][4]=idVendedor;
                String vendedor;
                if(idVendedor==1){
                    vendedor="Luis Perez";
                }
                else{
                vendedor="Mario rodriguez";
                        }
                for(int j=0;j<2;j++){
                if(vendedores[j][0]==idVendedor){
                    vendedores[j][1]=vendedores[j][1]+1;
                }}
                venta[i][5]=codigoProducto;
                String codigoProductoString;
                codigoProductoString=String.valueOf(codigoProducto); 
                for(int k=0;k<10;k++){
                if(productos[k][0].equals(codigoProductoString)){
                    int valor;
                    valor=Integer.parseInt(productos[k][2]);
                    venta[i][6]=cantidades;
                    venta[i][8]=valor*cantidades;
    }}
                venta[i][7]=formaDePago;
                String forma;
                if(formaDePago==0){
                    forma="Efectivo";
                }
                if(formaDePago==1){
                    forma="Debito";
                }
                else{
                    forma="Credito";
                }
                System.out.println("Datos de la venta:");
                
                System.out.println(dia+"/"+mes+"/"+anno+"/"+"Hora:"+hora+" Vendedor: "+vendedor+" Codigo: "+codigoProducto+" Cantidades: "+cantidades+" Forma de pago: "+forma+ "Valor de la venta: "+(venta[i][8])*0.9);
               
                System.out.println("Venta ingresada");
                 menu(productos, venta, vendedores);
                  }
                  
              }
    }
    public static void VendedorQueMasVendio(String [][] productos, int [][] venta, int [][] vendedores){
        if(vendedores[0][1]>vendedores[1][1]){
            System.out.println("El vendedor que mas vendio fue Luis Perez con "+vendedores[0][1]+ " ventas");
        }
        if(vendedores[0][1]<vendedores[1][1]){
            System.out.println("El vendedor que mas vendio fue Mario Rodriguez con "+vendedores[1][1]+ " ventas");
        }
        else{
            System.out.println("Ambos llevan el mismo numero de ventas con  "+vendedores[1][1]+ " ventas");
            
        }
        
        menu(productos, venta, vendedores);
        
    }
    public static void ListadoVentasDebito(String [][] productos, int [][] venta, int [][] vendedores){
        for(int i=0;i<10;i++){
        if(venta[i][4]==1&&venta[i][7]==2){
            System.out.println(venta[i][0]+"/"+venta[i][1]+"/"+venta[i][2]+"/"+ " Hora: "+venta[i][3]+" Vendedor: "+"Luis Perez"+" Codigo: "+venta[i][5]+" Cantidades: "+venta[i][6]+" Forma de pago: Debito Valor de la venta: "+(venta[i][8])*0.9);
        }}
        for(int i=0;i<10;i++){
        if(venta[i][4]==2&&venta[i][7]==2){           
            System.out.println(venta[i][0]+"/"+venta[i][1]+"/"+venta[i][2]+"/"+ " Hora: "+venta[i][3]+" Vendedor: "+"Mario Rodriguez"+" Codigo: "+venta[i][5]+" Cantidades: "+venta[i][6]+" Forma de pago: Debito Valor de la venta: "+(venta[i][8])*0.9);
        }}
        
        menu(productos, venta, vendedores);
    
    }
    public static void TotalVentas(String [][] productos, int [][] venta, int [][] vendedores){
        int totalVentas=0;
        for(int i=0;i<10;i++){
            totalVentas=totalVentas+venta[i][8];
            
        }
        System.out.println("El total de ventas ha sido de: "+ totalVentas);
        
        menu(productos, venta, vendedores);
    }
    public static void MayorVentaEnTarjeta(String [][] productos, int [][] venta, int [][] vendedores){
        int [] arreglo=new int[10];        
        for(int i=0;i<10;i++){
            if(venta[i][7]==2){
            arreglo[i]=venta[i][8]; 
        }}
        for(int i=0;i<(arreglo.length-1);i++){
            for(int j=i+1;j<arreglo.length;j++){
                if(arreglo[i]<arreglo[j]){                   
                    int variableauxiliar=arreglo[i];
                    arreglo[i]=arreglo[j];
                    arreglo[j]=variableauxiliar;
 
                }
            }
        }
        for(int i=1; i<10;i++){
            if(venta[i][8]==arreglo[1]){
                
                System.out.println("La venta que mas aporto en tarjeta de credito fue:");
                System.out.println(venta[i][0]+"/"+venta[i][1]+"/"+venta[i][2]+" A la hora "+venta[i][3]+"Hecha por el vendedor con ID:"+venta[i][4]+" Codigo del producto: "+venta[i][5]+" Cantidades"+venta[i][6]+"  Por un valor total de: "+venta[i][8]);
        menu(productos, venta, vendedores);
            }
        }      
        
    }
    public static void ConsultaVendedorProducto(String [][] productos, int [][] venta, int [][] vendedores){
        System.out.println("Ingrese ID del vendedor a consultar");
        Scanner entradaCodigoVendedor= new Scanner(System.in);
        int idVendedor= entradaCodigoVendedor.nextInt();
        System.out.println("Ingrese codigo del producto: ");
        Scanner entradaCodigoProducto= new Scanner(System.in);
        int codigo=entradaCodigoProducto.nextInt();
        boolean bandera= false;
        for(int i=0;i<10;i++){
            if(venta[i][4]==idVendedor&&venta[i][5]==codigo){
                bandera=true;
                System.out.println(venta[i][0]+"/"+venta[i][1]+"/"+venta[i][2]+"/"+ " Hora: "+venta[i][3]+" Vendedor: "+venta[i][4]+" Codigo: "+venta[i][5]+" Cantidades: "+venta[i][6]+" Forma de pago: "+venta[i][7]+ "Valor de la venta: "+(venta[i][8])*0.9);
                }
        }
        if(bandera==false){
            System.out.println("El vendedor con codigo: "+idVendedor+" No ha vendido el producto con Codigo: "+codigo);            
        }
        menu(productos, venta, vendedores);
        
    }
    public static void main(String[] args) {
       System.out.println("Bienvenido");
       String [][] productos= new String [10][3];
       int [][] venta= new int[10][9];
       for(int i=0;i<10;i++){ 
           for(int j=0;j<9;j++){
           venta[i][j]=0;
       }} 
       int [][] vendedores=new int[2][2];
       vendedores[0][0]=1;
       vendedores[0][1]=0;
       vendedores[1][0]=2;
       vendedores[1][1]=0;
           
       
       menu(productos, venta, vendedores);
       
    }
    
}
