/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio_i;

/**
 *
 * @author Usuario
 */
public class Laboratorio1_2 {
public static void main(String[] args) { 
        int cuenta_as = 1;
	int contador = 1;
	int blan = 1;
	int num = 5;
	char ast = '*';
	char esp = ' ';
	
	System.out.println ("");
 
for(contador=1; contador<=num; contador=contador+1){
	blan=num-contador;
		if(blan>0){
		System.out.println (esp);
		blan = blan-1;
}
	else{
		for(cuenta_as=1; cuenta_as<(2*contador); cuenta_as=cuenta_as+1){
	System.out.println (ast);
	}
	System.out.println ("");       
}
}
}
}

	
   
