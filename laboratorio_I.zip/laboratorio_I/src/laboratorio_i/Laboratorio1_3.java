/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio_i;

/**
 *
 * @author Usuario
 */
public class Laboratorio1_3 {
 public static void main(String[] args){
     System.out.println ("Primera función en Main");
 func1 ();
 func2 ();
     
     System.out.println ("Se termina Main");
 }
 
public static void func1(){
    System.out.println ("Segunda función");
}

public static void func2(){
    System.out.println ("Tercera función");
}
}
