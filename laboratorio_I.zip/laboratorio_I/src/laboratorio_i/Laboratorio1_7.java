package laboratorio_i;

public class Laboratorio1_7 {

    public static void menu(String arreglo[], int ingresos) {
        System.out.println();
        System.out.println("BIENVENIDO - Horario de atención de 06:00 a 20:00");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Asignar parqueadero");
        System.out.println("2. Valor a cancelar");
        System.out.println("3. Ingresos del día");
        System.out.println("4. SALIR");

        java.util.Scanner entradaMenu = new java.util.Scanner(System.in);
        int opcionMenu = entradaMenu.nextInt();
        if (opcionMenu == 1) {
            AsignarParqueadero(arreglo,ingresos);
        }
        if (opcionMenu == 2) {
            Pago(arreglo,ingresos);
        }
        if (opcionMenu == 3) {
            IngresosDia(arreglo,ingresos);
        }
        if (opcionMenu == 4) {
            System.exit(0);
        }
    }

    public static void AsignarParqueadero(String arreglo[], int ingresos) {
        java.util.Scanner teclado = new java.util.Scanner(System.in);
      
        for (int i = 0; i < 87; i++) {
            if ((arreglo[i])== "libre") {
                System.out.println("Debe parquear en: " + (i+1));
                System.out.println("Ingrese la placa del vehículo: ");
               String placa = teclado.next();
                arreglo[i] = placa;
                menu(arreglo,ingresos);
            } else {
                System.out.println("No hay cupo");
            }
            int dis = 86 - i;
            System.out.println("Quedan " + dis + "cupos libres");
         }
        
       menu(arreglo,ingresos);  
    }

    public static void Pago(String arreglo[], int ingresos) {
    java.util.Scanner teclado = new java.util.Scanner(System.in);  
    System.out.println("Por favor ingrese las horas de forma militar");
    System.out.println("Digite únicamente la hora de entrada:");
    int horaEntrada = teclado.nextInt();
    System.out.println("Digite únicamente la hora de salida:");
    int horaSalida = teclado.nextInt();	
    int numeroHoras = horaSalida - horaEntrada;
    int fraccion = 3000;
    int pago = numeroHoras * fraccion;
    System.out.println("El valor a cancelar es de $" +pago+ "pesos, por permanecer " +numeroHoras+ "horas");
    
    ingresos = ingresos + pago;
    menu(arreglo,ingresos);
    }

    public static void IngresosDia(String arreglo[], int ingresos) {
    System.out.println("Los ingresos del día son: $" + ingresos + "pesos");
        menu(arreglo,ingresos);
    }

    public static void main(String[] args) {

        String[] arreglo = new String[87];
        for (int a = 0; a < arreglo.length; a++) {
            arreglo[a] = "libre";
        }
        int ingresos = 0;
        menu(arreglo,ingresos);
    }
}
