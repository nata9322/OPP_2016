/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio_i;

/**
 *
 * @author Usuario
 */
public class Laboratorio1_1 {
    public static void main(String[] args) {
       java.util.Scanner lectura = new java.util.Scanner(System.in);
    	int mayor=0;
	int a,b,c;
	
    System.out.println ("Ingrese el valor de A");
    a=lectura.nextInt();
    
    System.out.println ("Ingrese el valor de B");
    b=lectura.nextInt();
    
    System.out.println ("Ingrese el valor de C");
    c=lectura.nextInt();
    
     if(a>b){
	        if(a>c){
	                mayor=a;	
 	               }
	        else{
	            mayor=c;	
	            }
	        }
    else{
	     if(b>c){
	             mayor=b;	
	            }  
	     else{
	          mayor=c;	
	         }
        }
    System.out.println ("El mayor es:" + mayor);
    
    }
}
