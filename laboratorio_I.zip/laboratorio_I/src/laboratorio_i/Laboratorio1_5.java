package laboratorio_i;

import java.util.Arrays;

public class Laboratorio1_5 {

    public static void menu(int matriz[][], int arreglo[]) {
        System.out.println();
        System.out.println("BIENVENIDO - Sistema para el conteo de votos");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Ingrese los votos");
        System.out.println("2. Reporte general de votaciones");
        System.out.println("3. Votos recibidos por candidato");
        System.out.println("4. Porcentaje de las votaciones");
        System.out.println("5. ¿Cuál es el ganador?");
        System.out.println("6. Orden de los votos");
        System.out.println("7. SALIR");

        java.util.Scanner entradaMenu = new java.util.Scanner(System.in);
        int opcionMenu = entradaMenu.nextInt();
        if (opcionMenu == 1) {
            Votos(matriz, arreglo);
        }
        if (opcionMenu == 2) {
            Reporte(matriz, arreglo);
        }
        if (opcionMenu == 3) {
            VotosPorCandidato(matriz, arreglo);
        }
        if (opcionMenu == 4) {
            PorcentajeVotaciones(matriz, arreglo);
        }
        if (opcionMenu == 5) {
            Ganador(matriz, arreglo);
        }
        if (opcionMenu == 6) {
            OrdenVotaciones(matriz, arreglo);
        }
        if (opcionMenu == 7) {
            System.exit(0);
        }
    }

    public static void Votos(int matriz[][], int arreglo[]) {
        java.util.Scanner teclado = new java.util.Scanner(System.in);
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("Ingrese el número de votos en el municipio " + (i + 1) + " para el candidato " + (j + 1) + ": ");
                matriz[i][j] = teclado.nextInt();
            }
        }
        menu(matriz, arreglo);
    }

    public static void Reporte(int matriz[][], int arreglo[]) {
        System.out.println("Consolidado de las votaciones");
        for (int k = 0; k < matriz.length; k++) {
            for (int l = 0; l < matriz[k].length; l++) {
                System.out.print(matriz[k][l] + "\t");
            }
            System.out.println();
        }
        menu(matriz, arreglo);
    }

    public static void VotosPorCandidato(int matriz[][], int arreglo[]) {
        int candidato = 0;
        for (int n = 0; n < matriz[0].length; n++) {
            for (int p = 0; p < matriz.length; p++) {

                candidato = matriz[p][n] + candidato;

            }
            System.out.println("El total de votos para el candidato " + (n + 1) + " es: " + candidato);
            arreglo[n] = candidato;
            candidato = 0;
        }

        menu(matriz, arreglo);
    }

    public static void PorcentajeVotaciones(int matriz[][], int arreglo[]) {
        int totalVotos = 0;
        for (int w = 0; w < arreglo.length; w++) {
            totalVotos = totalVotos + arreglo[w];
        }
        System.out.println("El total de votos fue: " + totalVotos);
        float porcentajeVotos = 0;
        for (int w = 0; w < arreglo.length; w++) {
            porcentajeVotos = (arreglo[w] * 100) / totalVotos;
            System.out.println("El porcentaje de votos para el candidato " + (w + 1) + " es: " + porcentajeVotos + "%");
        }
        menu(matriz, arreglo);
    }

    public static void Ganador(int matriz[][], int arreglo[]) {
        int ganador = arreglo[0];
        
        for (int g = 1; g < arreglo.length; g++) {
            if (arreglo[g] > ganador) {
                ganador = arreglo[g];
            }
            if (arreglo[g] == ganador) {
            System.out.println("Hay empate - no hay ganador");
            menu(matriz, arreglo);
            }
          }
        System.out.println("El ganador es el candidato con " + ganador + " votos");
        menu(matriz, arreglo);
    }

    public static void OrdenVotaciones(int matriz[][], int arreglo[]) {
        System.out.print("El orden las votaciones es: ");

        Arrays.sort(arreglo);
        for (int i = 0; i < arreglo.length; i++) {

            System.out.print(" " + arreglo[i]);
        }
        menu(matriz, arreglo);
    }

    public static void main(String[] args) {
        java.util.Scanner teclado = new java.util.Scanner(System.in);
        System.out.print("Ingrese el numero de municipios:");
        int fila = teclado.nextInt();
        System.out.print("Ingrese el numero de candidatos:");
        int columna = teclado.nextInt();
        int matriz[][] = new int[fila][columna];
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = 0;
            }
        }

        int[] arreglo = new int[columna];
        for (int a = 0; a < arreglo.length; a++) {
            arreglo[a] = 0;
        }
        menu(matriz, arreglo);
    }
}
