
package juegoaliens;

public class Alienigena {
    
    String color;
    int numeroOjos;
    int numeroVidas;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNumeroOjos() {
        return numeroOjos;
    }

    public void setNumeroOjos(int numeroOjos) {
        this.numeroOjos = numeroOjos;
    }

    public int getNumeroVidas() {
        return numeroVidas;
    }

    public void setNumeroVidas(int numeroVidas) {
        this.numeroVidas = numeroVidas;
    }
    
    public Alienigena(String color, int numeroojos, int numeroVidas){
        this.setColor(color);
        this.setNumeroOjos(numeroojos);
        this.setNumeroVidas(numeroVidas);
    }
    
    @Override
    public String toString(){
        String informacion= "Este ser extraterrestre, es un Alien de color "+this.getColor()+", en su rostro tiene "+this.getNumeroOjos()+" y su número de vidas es "+this.getNumeroVidas();
    return informacion;
    }
    

    
    public static void main(String[] args) {
        
        Alienigena ET= new Alienigena("verde", 2, 5);
        Alienigena ALF= new Alienigena("cafe", 2, 1);
        Alienigena superman= new Alienigena("azul y rojo", 2, 1);
        Marte Beta= new Marte("Verde", 4,4);
        Jupiter alpha= new Jupiter("narajna",2,4);
        System.out.println(Beta);
        System.out.println(alpha);
        
        
    }
    
}
