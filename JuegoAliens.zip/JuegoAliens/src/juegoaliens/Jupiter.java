
package juegoaliens ;

class Jupiter extends Alienigena {

    public Jupiter(String color, int numeroojos, int numeroVidas) {
        super("Naranja", 4, numeroVidas);
    }
    
    @Override
    public String toString(){
        String informacion="Todos los jupiterianos son de color "+this.getColor()+" con "+this.getNumeroOjos()+" ojos"+" y su numero de vidas es "+this.getNumeroVidas();
    return informacion;
    }
    
}
