
package juegoaliens;


public class Marte extends Alienigena{

    public Marte(String color, int numeroOjos, int numeroVidas) {
        super(color, 2+numeroOjos, numeroVidas+5);
    }
    
    @Override
    public String toString(){
        String informacion="Este marciano es de color "+this.getColor()+" , tiene "+this.getNumeroOjos()+" ojos, tiene dos de mas de lo pensado, ya que asi es en Marte. "+"Su numero de vidas es "+this.getNumeroVidas()+", cinco de mas, ya que en marte tienen mucha vida ";
    return informacion;    
    }
    
}
