
package vehiculos;


public class Vehiculos {
    
    int serieMotor;
    String marca;
    int año;
    double precio;
    
    public Vehiculos(int serieMotor, String marca, int año, double precio){
        this.setSerieMotor(serieMotor);
        this.setMarca(marca);
        this.setAño(año);
        this.setPrecio(precio);
        
    }

    public int getSerieMotor() {
        return serieMotor;
    }

    private void setSerieMotor(int serieMotor) {
        this.serieMotor = serieMotor;
    }

    public String getMarca() {
        return marca;
    }

    private void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAño() {
        return año;
    }

    private void setAño(int año) {
        this.año = año;
    }

    public double getPrecio() {
        return precio;
    }

    private void setPrecio(double precio) {
        this.precio = precio;
    }
    
    

   
    public static void main(String[] args) {
        AutoDeLujo auto= new AutoDeLujo(4566,"toyota",2015,45000000, 2);
        Camionetas camioneta= new Camionetas(7451,"chevrolet",2014,70000000, 120.5);
        Vagoneta vagoneta= new Vagoneta(2541,"chevy",2013,12000000, 5);
        System.out.println(auto);
        System.out.println(camioneta);
        System.out.println(vagoneta);
    }
    
}
