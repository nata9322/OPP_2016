
package vehiculos;

/**
 *
 * @author Familia
 */
public class AutoDeLujo extends Vehiculos  {

   
    int cantidadPasajeros;
     public AutoDeLujo(int serieMotor, String marca, int año, double precio, int cantidadPasajeros ){
        super(serieMotor, marca, año, precio);
        this.setCantidadPasajeros(cantidadPasajeros);        
    
    }
    
    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

    private void setCantidadPasajeros(int cantidadPasajeros) {
        this.cantidadPasajeros = cantidadPasajeros;
    }
   
   
    

    @Override
    public String toString(){
       return (this.getSerieMotor()+" "+ this.getMarca()+" "+this.getAño()+" "+this.getPrecio()+" "+this.getCantidadPasajeros());
    }
}
