
package vehiculos;

public class Camionetas extends Vehiculos {
    double capacidadCarga;

    public Camionetas(int serieMotor, String marca, int año, double precio,double capacidadCarga ) {
        super(serieMotor, marca, año, precio);
        this.setCapacidadCarga(capacidadCarga);
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    private void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }
    
    
    @Override
    public String toString(){
       return (this.getSerieMotor()+" "+ this.getMarca()+" "+this.getAño()+" "+this.getPrecio()+" "+this.getCapacidadCarga());
    }
}
